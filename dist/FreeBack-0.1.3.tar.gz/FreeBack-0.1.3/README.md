# -----------------------FreeBack------------------------

**barbybar**： 事件驱动回测

**alpha**: 因子测试及检验

**event**：事件测试

**post**： 后处理模块

# -----------------------INSTALL-------------------------
Manual:     

              git clone https://github.com/LHanLi/FreeBack.git
              
              cd FreeBack
              
              python3 setup.py install --u
              
Automatic:

            pip3 install --upgrade --user   git+https://github.com/LHanLi/FreeBack.git

# ----------------------Hello world-----------------------
